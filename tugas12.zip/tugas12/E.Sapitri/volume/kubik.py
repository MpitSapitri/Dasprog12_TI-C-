def volume_kubik(sisi):
    return sisi ** 3